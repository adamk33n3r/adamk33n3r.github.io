My Portfolio Website

Written mostly from scratch. Used jQuery and some plugins for that.

It is a single page website with scrolling anchor links.
